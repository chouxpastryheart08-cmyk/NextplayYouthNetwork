NextPlay website refresh — October 1, 2026

Upload index.html and all PNG files together to your website root. CSS and JavaScript are included in index.html. Not deployed to the live website.

Palette: Royal Blue #1A5FD9, Turquoise #00B8D4, Golden Yellow #FFC72C, Purple #A33ED9, Deep Navy #0D2A6B. Existing logo and emblems retained.

Fox Pointe: October 31, 2026, noon–3 p.m. CDT. Official details: https://foxpointe.org/event/trick-or-treat-event/

Donation inquiries link to contact until a donation URL is supplied. No placeholder analytics. Fonts and stock backgrounds require internet.

Local assets and internal anchors validated. Browser rendering could not be tested in this environment.
